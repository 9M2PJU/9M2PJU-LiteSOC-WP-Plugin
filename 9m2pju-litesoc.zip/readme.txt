=== 9M2PJU LiteSOC ===
Contributors: piju9m2pju
Tags: security, litesoc, malware-scanning, cyber-security, brute-force
Requires at least: 5.0
Tested up to: 6.9
Requires PHP: 7.2
Stable tag: 1.1.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Donate link: https://buymeacoffee.com/9m2pju

LiteSOC security event tracking and threat detection for WordPress.

== Description ==

9M2PJU LiteSOC is a WordPress security plugin that integrates the power of [LiteSOC](https://litesoc.io) real-time threat detection and behavioral AI into your WordPress site.

= Key Features =

* **Real-time Event Ingestion**: Automatically tracks authentication, user management, and admin activities.
* **Hardened Security**: Includes IP validation (X-Forwarded-For support) and input sanitization.
* **Behavioral AI Detection**: Identifies Geo-Anomalies, Impossible Travel, and Brute-force attacks.
* **Admin Dashboard**: Sleek interface with integrated logo and real-time security logs.
* **Standardized Schema**: Uses the official LiteSOC event schema for maximum compatibility.

== Installation ==

1. Upload the `9m2pju-litesoc` folder to your `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Navigate to the 9M2PJU LiteSOC menu and enter your API Key from the LiteSOC Dashboard.

== Frequently Asked Questions ==

= Does this plugin work with reverse proxies? =
Yes, it includes X-Forwarded-For support for accurate IP tracking.

== Screenshots ==

1. The 9M2PJU LiteSOC Admin Dashboard.

== Changelog ==

= 1.1.1 =
* Initial release for WordPress.org submission.
* Updated to GPLv3 (latest GPL) for compliance.
* Fixed license declaration headers in readme.txt.

== Upgrade Notice ==

= 1.1.1 =
Initial release. Fixed license headers and documentation for WordPress.org submission.
